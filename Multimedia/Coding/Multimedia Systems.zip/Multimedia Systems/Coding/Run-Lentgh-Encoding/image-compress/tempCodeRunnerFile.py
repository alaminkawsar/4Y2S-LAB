for val in line:
    #     print(val)