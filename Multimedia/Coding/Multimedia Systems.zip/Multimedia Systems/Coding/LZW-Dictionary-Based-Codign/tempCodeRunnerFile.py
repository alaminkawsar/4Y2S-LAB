    print(entry)
